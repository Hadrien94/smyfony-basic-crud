<?php

namespace Controller;


/**
 * Class AbstractController est ce qu'on appelle une class abstraite
 * ---------------
 * Une class abstraite est une class qu'on ne peut pas instancier
 * (et donc ne peut pas créer un objet)
 * ------------------
 * Pour être utilisée elle doit OBLIGATOIREMENT être hérité
 * -----------------
 * Autre particularité elle peut comporter des méthodes abstraites
 * c'est-à-dire des fonctions déclarées mais non définies (dont le contenu n'a pas été écrit)
 */

abstract class AbstractController
{

    /**
     * Afficher une page à l'utilisateur
     * ----------------
     * Je passe à la fonction render le nom du fichier
     * @param string $page
     */
    protected function render(string $page, array $parameters = [])
    {

        include_once(__DIR__.'/../../templates/header.php');
        include_once(__DIR__.'/../../templates/' . $page . '.php');
        include_once(__DIR__.'/../../templates/footer.php');

    }
}