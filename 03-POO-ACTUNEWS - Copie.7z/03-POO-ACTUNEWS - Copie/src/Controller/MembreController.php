<?php

namespace Controller;


/**
 * Le Controller en charge de la gestion des membres
 */

class MembreController extends AbstractController
{

    /**
     * Page permettant l'inscription un utilisateur
     */
    public function inscription () {
        # echo '<h1>Je suis la page Inscription</h1>';
        $this->render('membre/inscription');

    }

    /**
     * Page permettant de connecter l'utilisateur
     */
    public function connexion () {
        # echo '<h1>Je suis la page Connexion</h1>';
        $this->render('membre/connexion');

    }

    public function profil () {
        # echo '<h1>Je suis la page Profil</h1>';
        $this->render('membre/profil');

    }
}