<?php

namespace Controller;



/*
 * L'objectif du DefaultController est de s'occuper de la gestion des pages principales du site
 * ------------------------
 * En héritant de AbstractController,
 * ma class DefaultController a maintenant accès
 * à l'ensemble des propriétés et méthodes de AbstractController
 * -----------------------
 * NB : Une class ne peut hériter que d'une seule autre class
 */


use Model\Article\Article;
use Model\Auteur\Auteur;
use Model\Db\DbFactory;

class DefaultController extends AbstractController
{

    /**
     * La fonction "home" est ce qu'on appelle
     * une action. Une action c'est une page.
     * ------------
     * Page d'Accueil du site
     */
    public function home() {

        # Récupération des derniers articles de la BDD
        $pdo = DbFactory::makePdo();

        # Récupération des derniers articles de la BDD
        # $query = $pdo->query('SELECT * FROM article, auteur
        #                       WHERE article.auteur_id = auteur.id
        #                            ORDER BY article.id DESC
        # ');

        # $articles = $query->fetchAll();


        # Récupération des articles v2
        $articleModel = new Article();

        /*
        echo '<pre>';
            print_r($articles);
        echo '</pre>';
        */

        # echo '<h1>Je suis la page Accueil dans le Controller</h1>';
        $this->render('default/home', [
            'articles' => $articleModel->findAll()
        ]);


        # Récupération des auteurs
        $auteur = new Auteur();

        $this->render('default/home', [
            'auteur' => $auteur->findAll()
        ]);
    }

    /**
     * Page permettant de lister les articles d'une catégorie
     */
    public function categorie() {
        # echo '<h1>Je suis la page Categorie dans le Controller</h1>';
        $this->render('default/categorie');
    }

    /**
     * Page permettant d'afficher un article
     */
    public function article() {
        # echo '<h1>Je suis la page Article dans le Controller</h1>';
        $this->render('default/article');
    }

}