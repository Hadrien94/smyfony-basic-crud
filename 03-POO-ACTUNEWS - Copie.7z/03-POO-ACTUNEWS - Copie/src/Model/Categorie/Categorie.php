<?php


namespace Model\Categorie;


use Model\Db\DbTable;

class Categorie extends DbTable
{
    protected $table = 'categorie';
}