<?php

namespace Model\Article;

use Model\Db\DbTable;

class Article extends DbTable
{

    protected $table = 'articles_view';
}