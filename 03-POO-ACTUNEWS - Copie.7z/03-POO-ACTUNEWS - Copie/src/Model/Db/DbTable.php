<?php


namespace Model\Db;

/**
 * Class DbTable
 * @package Model\Db
 */

abstract class DbTable
{
    # Nom de la table
    protected $table;

    # Clé primaire de la table dans laquelle je suis
    protected $primary = 'id';

    # Instance PDO
    private $db;

    public function __construct ()
{
    # Récupération de l'instance de PDO
    $this->db = DbFactory::makePdo();
}

    # Récupérer toutes les informations d'une table dans la BDD
    public function findAll(string $where = '', string $orderBy = '', string $limit = '', string $offset = '') : array
    {
        # Requête SELECT
        $sql = "SELECT * FROM " . $this->table;

        # Si $where n'est pas vide
        if(!empty($where)) {
            $sql .= 'WHERE ' . $where;
        }

        # Si $orderBy n'est pas vide
        if(!empty($orderBy)) {
            $sql .= 'ORDER BY ' . $orderBy;
        }

        # Si $limit n'est pas vide
        if(!empty($limit)) {
            $sql .= ' LIMIT ' . (int) $limit;
        }

        # Si $orderBy n'est pas vide
        if(!empty($offset)) {
            $sql .= ' OFFSET ' . (int) $offset;
        }

        /*
         * En fonction des paramètres passés par mon utilisateur,
         * ma requête SQL va se construire successivement
         */

        # Préparation et execution de la requête
        $query = $this->db->prepare($sql);
        $query->execute();

        # On retourne le resultat
        return $query->fetchAll();



    }
}