<?php

/*
 * Ma class DbFactory est déclaréee dans l'espace Model\Db
 * --------------------------------
 * Pour l'utiliser je devrai dorénavant indiquer à php son emplacement, son name space
 */
namespace Model\Db;


use PDO;

/**
 * Une Factory est une class capable de créer des objets
 * -----------------------------
 * C'est aussi un design pattern
 */

class DbFactory
{
    /**
     * Fabrique et retourne une instance de PDO
     * ----------------------------
     * Une fonction static est une fonction qui appartient directement à la class
     * et non à l'objet
     * De ce fait elle peut être appelée sans qu'une instance de l'objet
     * ait été créée.
     * ----------------------------
     * Une fonction static peut communiquer uniquement avec une fonction static
     * et pas avec une fonction non static
     */

    public static function makePdo(): PDO
    {
        # Connexion à la BDD
        $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);

        return $pdo;
    }

}