<?php


namespace Model\Auteur;


use Model\Db\DbTable;

class Auteur extends DbTable
{
    protected $table = 'auteur';
}