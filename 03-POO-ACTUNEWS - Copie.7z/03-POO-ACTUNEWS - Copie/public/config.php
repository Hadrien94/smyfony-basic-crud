<?php

# Connexion à la BDD
# define() permet de définir une constante
define('DB_HOST', 'localhost');
define('DB_NAME', 'actunews');
define('DB_USER', 'root');
define('DB_PASS', '');

# Configuration des chemins
define( 'PATH_ROOT', dirname(__FILE__, 2) );
define( 'PATH_PUBLIC', PATH_ROOT . '/public' );
define( 'PUBLIC_URL', '/FORMATION_HUGO/03-POO-ACTUNEWS/public/' );

