
<?php

use Model\Categorie\Categorie;

# Récupération des catégories de la BDD
$categorieModel = new Categorie();
$categories = $categorieModel->findALl();
?>

<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Actu News</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <!-- Style personnalisé -->
    <link rel="stylesheet" href="../public/assets/css/style.css">

</head>
<body>


<!--//*********************** DEBUT DU MENU *****************************-->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">Actunews</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link" href="<?= PUBLIC_URL ?>">Accueil<span class="sr-only">(current)</span></a>
            </li>
            <?php foreach ( $categories as $categorie ) { ?>
                <li>
                    <a class="nav-link" href="<?= PUBLIC_URL . '/default/categorie?id=' . $categorie['id'] ?>"><?= $categorie['nom'] ?></a>
                </li>
            <?php } ?>
        </ul>
    </div>
</nav>
<!--//******************** FIN DU MENU ***********************-->

