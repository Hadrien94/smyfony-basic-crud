<div class="p-3 mx-auto text-center">
    <h1 class="display-4">Je suis la page Article</h1>
</div>