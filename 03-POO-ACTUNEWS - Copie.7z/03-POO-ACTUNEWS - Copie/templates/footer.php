
<!-- Pied de page -->
<div class="container">
    <footer class="mt-4 pt-4 border-top">
        <div class="row">
            <div class="col-12 col-md">
                <h5>Actunews</h5>
                <small class="d-block text-muted">
                    &copy; <?= date ('Y') ?>
                </small>
            </div>

            <div class="col-6 col-md">
                <h5>Catégories</h5>
                <ul class="list-unstyled">
                    <?php foreach ( $categories as $categorie ) { ?>
                        <li>
                            <a class="nav-link" href="<?= PUBLIC_URL . '/default/categorie?id=' . $categorie['id'] ?>"><?= $categorie['nom'] ?></a>
                        </li>
                    <?php } ?>
                </ul>
            </div>

            <div class="col-6 col-md">
                <h5>En plus</h5>
                <ul class="list-unstyled">
                    <li><a href="#">Mentions légales</a></li>
                    <li><a href="#">Confidentialité</a></li>
                    <li><a href="#">Plan du site</a></li>
                </ul>
            </div>
        </div>
    </footer>
</div>
<!--*********************** Fin Pied de Page ****************************-->


</body>
</html>
